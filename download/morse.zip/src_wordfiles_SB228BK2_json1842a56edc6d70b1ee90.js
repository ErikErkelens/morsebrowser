"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK2_json"],{

/***/ "./src/wordfiles/SB228BK2.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB228BK2.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"28BK","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);