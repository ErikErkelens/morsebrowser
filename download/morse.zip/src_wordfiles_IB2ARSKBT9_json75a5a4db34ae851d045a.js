"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT9_json"],{

/***/ "./src/wordfiles/IB2ARSKBT9.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT9.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR><SK><BT>hof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);