"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_Fam_Phrases_3L_txt"],{

/***/ "./src/wordfiles/INT2_Fam_Phrases_3L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT2_Fam_Phrases_3L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "WE \r\nWE DONT \r\nWE DONT SEE \r\n{<BT>|}\r\nITS \r\nITS FINE \r\nITS FINE JUST \r\n{<BT>|}\r\nONCE \r\nONCE IN \r\nONCE IN A \r\n{<BT>|}\r\nTEN \r\nTEN CENTS \r\nTEN CENTS WONT \r\n{<BT>|}\r\nROLL \r\nROLL OVER \r\nROLL OVER THAT \r\n{<BT>|}\r\nWHEN \r\nWHEN PIGS \r\nWHEN PIGS FLY \r\n{<BT>|}\r\nA \r\nA PIECE \r\nA PIECE OF\r\n{<BT>|}\r\nHE \r\nHE ATE  \r\nHE ATE VERY \r\n{<BT>|}\r\nCALL \r\nCALL IT \r\nCALL IT A ";

/***/ })

}]);