"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2592_json"],{

/***/ "./src/wordfiles/SB2592.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2592.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);