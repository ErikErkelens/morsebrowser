"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_ZJ_txt"],{

/***/ "./src/wordfiles/BC2_FAM_ZJ.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/BC2_FAM_ZJ.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "Z \r\nJ \r\n/ \r\nJ \r\n/ \r\nZ \r\n/ \r\nZ \r\nJ \r\nZ \r\nJ \r\n/ \r\n";

/***/ })

}]);