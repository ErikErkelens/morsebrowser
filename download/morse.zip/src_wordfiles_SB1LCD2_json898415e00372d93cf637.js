"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1LCD2_json"],{

/***/ "./src/wordfiles/SB1LCD2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1LCD2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lcdpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);