"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB25910_json"],{

/***/ "./src/wordfiles/IB25910.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB25910.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"59,tin","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);