"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1REA4_json"],{

/***/ "./src/wordfiles/SB1REA4.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1REA4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reauwbhoflcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);