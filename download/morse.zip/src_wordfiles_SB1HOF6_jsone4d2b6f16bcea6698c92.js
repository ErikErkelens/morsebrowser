"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1HOF6_json"],{

/***/ "./src/wordfiles/SB1HOF6.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1HOF6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"hoflcdpgstinreauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);