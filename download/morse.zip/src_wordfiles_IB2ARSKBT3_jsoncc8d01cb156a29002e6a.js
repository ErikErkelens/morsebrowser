"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT3_json"],{

/***/ "./src/wordfiles/IB2ARSKBT3.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT3.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR><SK>","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);