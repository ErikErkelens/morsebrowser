"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_3_txt"],{

/***/ "./src/wordfiles/Fam_Words - 3.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 3.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "way \r\nthere \r\nfrom \r\nour \r\nmy \r\nsee \r\nany \r\nbe \r\nget \r\nas \r\nit \r\nonly \r\nfirst \r\nif \r\nat \r\na \r\nthe \r\nyou \r\nout \r\nwill \r\nwith \r\nher \r\nwe \r\nthink \r\n";

/***/ })

}]);