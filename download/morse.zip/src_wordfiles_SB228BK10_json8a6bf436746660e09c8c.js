"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK10_json"],{

/***/ "./src/wordfiles/SB228BK10.json":
/*!**************************************!*\
  !*** ./src/wordfiles/SB228BK10.json ***!
  \**************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb28bkzj/16.<ar><sk><bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);