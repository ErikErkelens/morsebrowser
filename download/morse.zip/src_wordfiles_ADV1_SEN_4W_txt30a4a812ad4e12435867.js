"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_SEN_4W_txt"],{

/***/ "./src/wordfiles/ADV1_SEN_4W.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/ADV1_SEN_4W.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "I love you so. \r\nThank you very much. \r\nOh no you didnt. \r\nI want you so. \r\nWritings on the wall. \r\nPut your dukes up. \r\nLet your hair down. \r\nFrom the horses mouth. \r\nI miss you so. \r\nWet behind the ears. \r\nPig in a poke. \r\nI need you so. \r\nPaint the town red. \r\nSkin of your teeth. \r\nGet in the sack. \r\nRaining cats and dogs. \r\nI am a rock. \r\nHigh on the hog. \r\nA stiff upper lip. \r\nSkeletons in the closet. \r\nClean as a whistle. \r\nThrow in the towel. \r\nBats in the belfry. \r\nFit as a fiddle. \r\nPull in the horns. \r\nCalled on the carpet. \r\nHes no spring chicken. \r\nGet the lead out. \r\nReveal your true colors. \r\nRide like the wind. \r\nThe whole nine yards. \r\nOne life one chance. \r\nThe past is practice. \r\nAbsent without official leave. \r\nLock, stock, and barrel. \r\nHook, line, and sinker. \r\nBeat around the bush. \r\nRead between the lines. \r\nTo make ends meet. \r\nRub the wrong way. \r\nWork the graveyard shift. \r\nDead as a doornail. \r\nNip in the bud. \r\nMy lips are sealed. \r\nBring home the bacon. \r\nSee, hear, touch, feel. \r\nGood luck to you. \r\nGo your own way. \r\nLive, breathe, laugh, love. \r\nHearts beat the same. \r\nIts all about me. \r\nTo thyself be true. \r\nI have a dream. \r\nThou shall not surrender. \r\nWhat did you say? \r\nNot on your life. \r\nI think I can. \r\nI only want now. \r\nI want it all. \r\nPeace, love, and understanding. \r\nDont rock the boat. \r\nSleep is not mandatory. \r\nGood guys always win. \r\nLive for your word. \r\nIts all about you. \r\nGod is my shield. \r\nI am not afraid. \r\nIts all in you. \r\nI stand my ground. \r\nTalk to the hand. \r\nI want to cry. \r\nNow leave me alone. \r\nGo out and play. \r\nMoney cant buy life. \r\nDon’t worry, be happy. \r\nJust go for it. \r\nMake love not war. \r\nJust like a man. \r\nJust like a woman. \r\nWork hard, play harder. \r\nYou are so beautiful. \r\nToo legit to quit. \r\nTrue love never dies. \r\nNice guys finish last. \r\nGod as my witness. \r\nFor old times sake. \r\nJust this one time. \r\nDont drink and drive. \r\nA moment like this. \r\nBe a good girl. \r\nIf you want me. \r\nDont fall in love. \r\nLets just be friends. \r\nTomorrow is another day. ";

/***/ })

}]);