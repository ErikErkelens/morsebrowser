"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2595_json"],{

/***/ "./src/wordfiles/IB2595.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2595.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);