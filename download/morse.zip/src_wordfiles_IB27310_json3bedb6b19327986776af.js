"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB27310_json"],{

/***/ "./src/wordfiles/IB27310.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB27310.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"73?lcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);