"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1REA1_json"],{

/***/ "./src/wordfiles/SB1REA1.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1REA1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"rea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);