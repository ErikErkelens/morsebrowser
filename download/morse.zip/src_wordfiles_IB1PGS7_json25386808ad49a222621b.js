"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS7_json"],{

/***/ "./src/wordfiles/IB1PGS7.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgstinrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);