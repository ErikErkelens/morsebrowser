"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB27310_json"],{

/***/ "./src/wordfiles/SB27310.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB27310.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);