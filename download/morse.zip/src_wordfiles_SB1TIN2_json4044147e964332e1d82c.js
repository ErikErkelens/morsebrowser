"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1TIN2_json"],{

/***/ "./src/wordfiles/SB1TIN2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1TIN2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tinrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);