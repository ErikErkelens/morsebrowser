"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_LCD_txt"],{

/***/ "./src/wordfiles/BC1_FAM_LCD.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_LCD.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "L \r\nC \r\nD \r\nC \r\nD \r\nL \r\nD \r\nL \r\nC \r\nL \r\nC \r\nD \r\n";

/***/ })

}]);