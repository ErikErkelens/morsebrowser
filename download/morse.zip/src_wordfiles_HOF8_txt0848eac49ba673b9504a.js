"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF8_txt"],{

/***/ "./src/wordfiles/HOF8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/HOF8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CO \nFL \n{OH|ohio} \n{OR|oregon} \nSC \nSD \n";

/***/ })

}]);