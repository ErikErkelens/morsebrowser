"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY1_json"],{

/***/ "./src/wordfiles/IB2KMY1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2KMY1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"k","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);