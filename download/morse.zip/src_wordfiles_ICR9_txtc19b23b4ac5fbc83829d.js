"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR9_txt"],{

/***/ "./src/wordfiles/ICR9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "NO TELL\nEARN A REST\nA CATS TAIL\nA CORE ROLE\nLET IT REST\nTELL IT ALL\nNOT ONE IOTA\nEASE INTO IT\nA COST I LOST\nI LOST A RACE\nTEAR IN A TIRE\nA SCAN AT NOON\nEAT IT OR ELSE\nA TEN CENT LOAN\nTOO SORE TO SIT\nI CANT CARE LESS\nONE ACRE TO A LOT\nI LOST A TEST LIST\nSLOT CARS ARE COOL\nLETS RACE TO A TREE\nIT ISNT A REAL NAIL\nITS TOO LATE TO EAT\nITS A REAL RAT RACE\nA LENS CAN TEAR\nA LION IS NOT AN ANT\nA COOT SAT ON A SEAT\nITS A REAL TEST TONE\nOIL IN A CAN\nLIE ON A COT IN RAIN \nA LAST ONE CAN ROLL IN\nA NEAT AREA TO SAIL IN\nLAST ONE TO LOSE A RACE\nCORN IN AN AREA\nIS IT A TALL TALE OR NOT\nLETS SIT ON A SEAT TO EAT\nA COOL CAT ATE A RATS TAIL\n\n\n";

/***/ })

}]);