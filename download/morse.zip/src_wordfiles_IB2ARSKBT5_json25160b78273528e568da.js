"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT5_json"],{

/***/ "./src/wordfiles/IB2ARSKBT5.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT5.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR><SK><BT>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);