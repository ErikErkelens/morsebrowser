"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB27314_json"],{

/***/ "./src/wordfiles/SB27314.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB27314.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,kmy4028bkzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);