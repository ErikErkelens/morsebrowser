"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY7_txt"],{

/***/ "./src/wordfiles/IB2KMY7.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY7.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "MY RIG KNWD\nANT DIPOLE\nANT YAGI\nOK OM SOLID CPY\nSOLID CPI\nFB CATHY\nNAME MIKE\nNAME HOWARD\nNAME RICH\nBEEN HAM TWO YRS\nSRI OM\nMY RIG ICOM\nMY RIG YAESU\nMY RIG TEN TEC\nMY RIG BOAT ANCHOR\nMY KEY BUG\nNICE SIG OM\n";

/***/ })

}]);