"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Q_txt"],{

/***/ "./src/wordfiles/Fam_Q.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/Fam_Q.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "QTH QRL QRM  QRN  QRP  QRQ  QRS  QRT  QRZ  QSB  QSY  QTH  QRL  QRM  QRN  QRP  QRQ  QRS  QRT  QRZ  QSB  QSY ";

/***/ })

}]);