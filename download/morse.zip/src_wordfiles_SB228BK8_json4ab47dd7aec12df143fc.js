"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK8_json"],{

/***/ "./src/wordfiles/SB228BK8.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB228BK8.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb28bkzj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);