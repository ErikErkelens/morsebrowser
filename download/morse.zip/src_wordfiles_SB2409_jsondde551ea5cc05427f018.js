"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2409_json"],{

/***/ "./src/wordfiles/SB2409.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2409.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);