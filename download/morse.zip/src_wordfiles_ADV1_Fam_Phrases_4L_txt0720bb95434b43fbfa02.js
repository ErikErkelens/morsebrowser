"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_Fam_Phrases_4L_txt"],{

/***/ "./src/wordfiles/ADV1_Fam_Phrases_4L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/ADV1_Fam_Phrases_4L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "He has \r\nHe has as many \r\nHe has as many children as \r\nHe has as many children as they do \r\n{<BT>|}\r\nThere are \r\nThere are only five \r\nThere are only five students here \r\nThere are only five students here this day \r\n{<BT>|}\r\nThis is \r\nThis is what an  \r\nThis is what an orange looks \r\nThis is what an orange looks like inside \r\n{<BT>|}\r\nPlease be \r\nPlease be quiet, the \r\nPlease be quiet, the baby is \r\nPlease be quiet, the baby is sleeping now \r\n ";

/***/ })

}]);