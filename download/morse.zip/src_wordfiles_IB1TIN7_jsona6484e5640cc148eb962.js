"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN7_json"],{

/***/ "./src/wordfiles/IB1TIN7.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tinreauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);