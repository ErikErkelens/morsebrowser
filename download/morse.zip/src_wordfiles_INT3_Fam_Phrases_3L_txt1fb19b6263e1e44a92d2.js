"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_Fam_Phrases_3L_txt"],{

/***/ "./src/wordfiles/INT3_Fam_Phrases_3L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT3_Fam_Phrases_3L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "THE BEST \r\nTHE BEST OF BOTH \r\nTHE BEST OF BOTH WORLDS \r\n{<BT>|}\r\nHELLO, HOW \r\nHELLO, HOW ARE YOU \r\nHELLO, HOW ARE YOU THIS MORNING? \r\n{<BT>|}\r\nTO ADD \r\nTO ADD INSULT TO \r\nTO ADD INSULT TO INJURY \r\n{<BT>|}\r\nROLL OVER \r\nROLL OVER THAT BUMP \r\nROLL OVER THAT BUMP IN THE STREET \r\n{<BT>|}\r\nWE DONT \r\nWE DONT SEE EYE \r\nWE DONT SEE EYE TO EYE \r\n";

/***/ })

}]);