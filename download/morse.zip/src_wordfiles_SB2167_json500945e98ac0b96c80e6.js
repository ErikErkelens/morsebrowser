"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2167_json"],{

/***/ "./src/wordfiles/SB2167.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2167.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);