"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_2_txt"],{

/***/ "./src/wordfiles/Fam_Words - 2.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 2.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "he \r\nhow \r\nby \r\ncould \r\nhis \r\nnot \r\nno \r\nperson \r\non \r\nwork \r\ngood \r\nknow \r\nwhen \r\nI \r\nlook \r\ngo \r\nday \r\ncome \r\nover \r\nsay \r\nto \r\nfor \r\nabout \r\nthem \r\ncan \r\n";

/***/ })

}]);