"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_REA_txt"],{

/***/ "./src/wordfiles/BC1_FAM_REA.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_REA.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "R \r\nE \r\nA \r\nE \r\nA \r\nR \r\nA \r\nR \r\nE \r\nR \r\nE \r\nA \r\n";

/***/ })

}]);