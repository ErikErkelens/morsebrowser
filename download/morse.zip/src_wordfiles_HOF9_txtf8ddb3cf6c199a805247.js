"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF9_txt"],{

/***/ "./src/wordfiles/HOF9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/HOF9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "C OP\n";

/***/ })

}]);