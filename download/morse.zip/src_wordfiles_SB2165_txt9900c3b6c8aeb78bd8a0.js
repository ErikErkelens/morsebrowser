"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2165_txt"],{

/***/ "./src/wordfiles/SB2165.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2165.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "N1CC N1EA N1SG NE1D WO6W AC6D N6GE N6IE N1TD AB1TF WB6WUB AC1LDE AB6DL WB6ARF N6OH N1CL  \n";

/***/ })

}]);