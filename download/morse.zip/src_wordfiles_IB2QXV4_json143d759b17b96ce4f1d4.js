"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV4_json"],{

/***/ "./src/wordfiles/IB2QXV4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2QXV4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"v","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);