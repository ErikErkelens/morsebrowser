"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB25911_json"],{

/***/ "./src/wordfiles/SB25911.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB25911.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy4028bkzj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);