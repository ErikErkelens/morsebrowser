"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_16_txt"],{

/***/ "./src/wordfiles/BC2_FAM_16.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/BC2_FAM_16.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "1 \r\n6 \r\n. \r\n6 \r\n. \r\n1 \r\n. \r\n1 \r\n6 \r\n1 \r\n6 \r\n. \r\n";

/***/ })

}]);