"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK2_json"],{

/***/ "./src/wordfiles/IB228BK2.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB228BK2.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"8","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);