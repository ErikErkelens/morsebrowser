"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2732_json"],{

/***/ "./src/wordfiles/IB2732.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2732.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"3","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);