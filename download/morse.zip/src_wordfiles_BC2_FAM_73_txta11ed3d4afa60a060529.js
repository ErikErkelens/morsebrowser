"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_73_txt"],{

/***/ "./src/wordfiles/BC2_FAM_73.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/BC2_FAM_73.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "7 \r\n3 \r\n? \r\n3 \r\n? \r\n7 \r\n? \r\n7 \r\n3 \r\n7 \r\n3 \r\n? \r\n";

/***/ })

}]);