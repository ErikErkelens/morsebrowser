"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK8_txt"],{

/***/ "./src/wordfiles/IB228BK8.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK8.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "W2ITT I2RTF N2DEE N2GSL N2PPI W2NDG W2LCW WB8WUB AC8LL AB8DU WB8FAR  \n";

/***/ })

}]);