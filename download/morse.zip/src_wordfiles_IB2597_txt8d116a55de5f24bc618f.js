"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2597_txt"],{

/***/ "./src/wordfiles/IB2597.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2597.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AB5TN DE N5DR GA FRED\nSOLID CPI\nUR RST 599 5NN\nATLANTA, GA\nORLANDO, FL\nSEATTLE, WA\nWASHINGTON, DC\nCHICAGO, IL\nBOISE, ID\nNR SFO, CA\nAGE 59\nWIND ES RAIN\nRETIRED COP\nRETIRED AIRLINE PILOT\nPWR 5W\n";

/***/ })

}]);