"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2594_txt"],{

/***/ "./src/wordfiles/SB2594.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2594.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AB5TN DE N5DR GA FRED\nSOLID CPI\nUR RST 599 5NN\nATLANTA, GA\nORLANDO, FL\nSEATTLE, WA\nWASHINGTON, DC\nCHICAGO, IL\nBOISE, ID\nNR SFO, CA\nAGE 59\nWIND ES RAIN\nRETIRED COP\nRETIRED AIRLINE PILOT\nPWR 5W\n";

/***/ })

}]);