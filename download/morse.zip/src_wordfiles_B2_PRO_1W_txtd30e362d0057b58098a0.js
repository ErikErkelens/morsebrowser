"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_B2_PRO_1W_txt"],{

/***/ "./src/wordfiles/B2_PRO_1W.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/B2_PRO_1W.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "CPI <BT>\r\nSRI  <SK>\r\nBTU <AR>\r\nHW <BT>\r\nSOLID <AR>\r\nCLEAR <SK>\r\nAGN <BT>\r\nCUAGN <SK>\r\nPWR <BT>\r\nSIG <BT>\r\nRAIN <AR>\r\nRIG <BT>\r\nCALL <AR>\r\nRETIRED <BT>\r\nWUD <SK>\r\nFER <AR>\r\nBEEN <BT>\r\nES <AR>\r\nRST <SK>\r\nPSE <BT>\r\nINFO <AR>";

/***/ })

}]);