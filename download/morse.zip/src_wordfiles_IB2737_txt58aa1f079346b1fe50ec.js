"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2737_txt"],{

/***/ "./src/wordfiles/IB2737.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2737.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ES HP CUAGN\nHW?\nAC3D DE N3GE\nAGE 37\nANT DIPOLE UP 73 FT\nANT EFHW UP 37 FT\nANT WIRE IN ATTIC\nAGE 73 RETIRED DOCTOR\nPSE RPT RIG ES ANT?\nOP FLIP\nRIG TEN TEC\nSOLID SIG HR\nCOLD ES RAIN 3 C\nCUL DR SOCHO\n";

/***/ })

}]);