"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1PGS6_json"],{

/***/ "./src/wordfiles/SB1PGS6.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1PGS6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgstinreauwbhoflcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);