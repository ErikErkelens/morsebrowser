"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_40_txt"],{

/***/ "./src/wordfiles/BC2_FAM_40.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/BC2_FAM_40.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "4 \r\n0 \r\n0 \r\n0 \r\n0 \r\n4 \r\n0 \r\n4 \r\n0 \r\n4 \r\n0 \r\n0 \r\n";

/***/ })

}]);