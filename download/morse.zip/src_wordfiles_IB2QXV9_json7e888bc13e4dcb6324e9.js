"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV9_json"],{

/***/ "./src/wordfiles/IB2QXV9.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2QXV9.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"qxvpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);