"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_B2_PRO_2W_txt"],{

/***/ "./src/wordfiles/B2_PRO_2W.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/B2_PRO_2W.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "HW CPI <BT>\r\nPSE AGN <BT>\r\nSOLID SIG <AR>\r\nSRI RST <BT>\r\nSRI CLEAR <SK>\r\nRIG PWR <AR>\r\nANT DIPOSE <BT>\r\nWIND RAIN <AR>\r\nHOT SUN <BT>\r\nES CLEAR <SK>\r\nSOLID CPI <BT>\r\nRETIRED OP <SK>\r\nHP CUAGN <SK>\r\nABT RIG <BT>\r\nBEEN HOT <AR>\r\nWIND ES <BT>\r\nWUD HPE <BT>";

/***/ })

}]);