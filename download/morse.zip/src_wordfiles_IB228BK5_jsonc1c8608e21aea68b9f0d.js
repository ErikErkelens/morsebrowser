"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK5_json"],{

/***/ "./src/wordfiles/IB228BK5.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB228BK5.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"28BK","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);