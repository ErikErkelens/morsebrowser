"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_json"],{

/***/ "./src/wordfiles/INT3.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT3.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890.,?/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);