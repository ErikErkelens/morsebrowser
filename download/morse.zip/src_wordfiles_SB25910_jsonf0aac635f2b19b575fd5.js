"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB25910_json"],{

/***/ "./src/wordfiles/SB25910.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB25910.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);