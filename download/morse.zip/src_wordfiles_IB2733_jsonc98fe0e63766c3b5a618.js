"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2733_json"],{

/***/ "./src/wordfiles/IB2733.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2733.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"73","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);