"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2735_txt"],{

/***/ "./src/wordfiles/SB2735.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2735.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AC3D N3GE N3IOE N7RD AB7NT WB3WUB WB3OHF AA7TIN AC7CLD AB7CDL WB3EAR N3FOH N7CDL  \n";

/***/ })

}]);