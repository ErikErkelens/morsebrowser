"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY6_txt"],{

/***/ "./src/wordfiles/IB2KMY6.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY6.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "ABT AGE AGN AM ANT BEEN BK BUG C CFM CLEAR CPI CPY CU CUAGN CUL CW DE DN DR EL ES FB FER FM FT GA GE GM GN GND GUD HAM HI HPE HR HW INFO K OK OM OP OT PSE PWR R RAIN RFI RIG RPRT RPT RR RST SIG SKED SOLID SRI SSB SUN T TEMP TKS TU U UP UR W WID WIND WPM WUD YAGI YRS \n";

/***/ })

}]);