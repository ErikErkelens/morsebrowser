"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT4_json"],{

/***/ "./src/wordfiles/INT4.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT4.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":".,/?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);