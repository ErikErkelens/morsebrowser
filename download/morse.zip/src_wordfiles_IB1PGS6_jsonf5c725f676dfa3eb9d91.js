"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS6_json"],{

/***/ "./src/wordfiles/IB1PGS6.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tinrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);