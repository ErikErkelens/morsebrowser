"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1PGS5_json"],{

/***/ "./src/wordfiles/SB1PGS5.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1PGS5.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgstinreauwbhof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);