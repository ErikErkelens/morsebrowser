"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1REA1_json"],{

/***/ "./src/wordfiles/IB1REA1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1REA1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"r","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);