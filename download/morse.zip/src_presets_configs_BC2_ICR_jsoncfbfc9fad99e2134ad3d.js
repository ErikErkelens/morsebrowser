"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_configs_BC2_ICR_json"],{

/***/ "./src/presets/configs/BC2_ICR.json":
/*!******************************************!*\
  !*** ./src/presets/configs/BC2_ICR.json ***!
  \******************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"morseSettings":[{"key":"wpm","value":27,"comment":null},{"key":"fwpm","value":27,"comment":null},{"key":"preSpace","value":"0","comment":null},{"key":"xtraWordSpaceDits","value":"1","comment":null},{"key":"volume","value":"7","comment":null},{"key":"stickySets","value":"BK","comment":null},{"key":"ifStickySets","value":false,"comment":null},{"key":"syncWpm","value":false,"comment":null},{"key":"hideList","value":true,"comment":null},{"key":"showRaw","value":false,"comment":null},{"key":"autoCloseLessonAccordian","value":false,"comment":null},{"key":"cardFontPx","value":"15","comment":null},{"key":"customGroup","value":"","comment":null},{"key":"showExpertSettings","value":"true","comment":null},{"key":"voiceEnabled","value":true,"comment":null},{"key":"voiceSpelling","value":true,"comment":null},{"key":"voiceThinkingTime","value":"0.75","comment":null},{"key":"voiceAfterThinkingTime","value":0,"comment":null},{"key":"voiceVolume","value":10,"comment":null},{"key":"voiceLastOnly","value":false,"comment":null},{"key":"voiceRecap","value":false,"comment":null},{"key":"keepLines","value":false,"comment":null},{"key":"syncSize","value":false,"comment":null},{"key":"overrideSize","value":true,"comment":null},{"key":"overrideSizeMin","value":"1","comment":null},{"key":"overrideSizeMax","value":"1","comment":null},{"key":"cardSpace","value":0,"comment":"AKA cardWait"},{"key":"hapticAccordionOpen","value":false,"comment":null},{"key":"miscSettingsAccordionOpen","value":"true","comment":null},{"key":"speedInterval","value":false,"comment":null},{"key":"intervalTimingsText","value":"30, 30, 30, 30","comment":null},{"key":"intervalWpmText","value":"12","comment":null},{"key":"intervalFwpmText","value":"8, 10, 11, 12","comment":null},{"key":"voiceBufferMaxLength","value":"1","comment":null},{"key":"speakFirst","value":false,"comment":null},{"key":"speakFirstRepeats","value":0,"comment":null},{"key":"speakFirstAdditionalWordspaces","value":0,"comment":null}]}');

/***/ })

}]);