"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR4_txt"],{

/***/ "./src/wordfiles/ICR4.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR4.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\nI\nAT\nIT\nNO\nTO\nAS\nSO\nOR\nAN\nON\nIN\nIS\nANT\nTOE\nONE\nRAT\nSAT\nEAT\nSIT\nCAR\nACE\nCAT\nOAR\nSET\nARE\nSEE\nACT\nTAN\nRAN\nEEL\nNOR\nTIN\nATE\nCAN\nOIL\nILL\nLOT\nCOT\nNOT\nTEN\nLIE\nALL\nITS\n\n";

/***/ })

}]);