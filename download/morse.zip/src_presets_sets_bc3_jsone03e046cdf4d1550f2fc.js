"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_bc3_json"],{

/***/ "./src/presets/sets/bc3.json":
/*!***********************************!*\
  !*** ./src/presets/sets/bc3.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"BC3_DEFAULT_12.json"},{"display":"Default 15/12","filename":"BC3_DEFAULT_15.json"},{"display":"Call Signs","filename":"BC3_CS.json"},{"display":"Familiarity Phrases","filename":"BC3_FAM_Phrases.json"},{"display":"Familiarity Spelling","filename":"BC3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"BC3_FAM_Words.json"},{"display":"Sending Practice","filename":"BC3_SENDING.json"}]}');

/***/ })

}]);