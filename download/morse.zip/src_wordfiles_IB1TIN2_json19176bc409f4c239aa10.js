"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN2_json"],{

/***/ "./src/wordfiles/IB1TIN2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"i","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);