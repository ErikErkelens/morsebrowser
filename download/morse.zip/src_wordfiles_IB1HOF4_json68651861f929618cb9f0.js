"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF4_json"],{

/***/ "./src/wordfiles/IB1HOF4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"f","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);