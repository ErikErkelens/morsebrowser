"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Fam_Contest1_txt"],{

/***/ "./src/wordfiles/BC3_Fam_Contest1.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Fam_Contest1.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "UR 599 \r\nUR 599 {TX|texas} NAME \r\nUR 599 {TX|texas} NAME TOM SKCC \r\nUR 599 {TX|texas} NAME TOM SKCC {NR|number} {9877|9 8 7 7} \r\n{<BT>|}\r\nUR {359|3 5 9}\r\nUR {359|3 5 9}AZ NAME \r\nUR {359|3 5 9}AZ NAME MIKE SKCC \r\nUR {359|3 5 9} AZ NAME MIKE SKCC {NR|number} {8374|8 3 7 4}\r\n{<BT>|}\r\n{WB2UZE|W B 2 U Z E} TNX \r\n{WB2UZE|W B 2 U Z E} TNX {359|3 5 9} {359|3 5 9}\r\n{WB2UZE|W B 2 U Z E} TNX {359|3 5 9} {359|3 5 9} BK TU \r\n{WB2UZE|W B 2 U Z E} TNX {359|3 5 9} {359|3 5 9} BK TU 599 599 \r\n{<BT>|}\r\n{KB4QQJ|K B 4 Q Q J} TU \r\n{KB4QQJ|K B 4 Q Q J} TU 2D KS \r\n{KB4QQJ|K B 4 Q Q J} TU 2D KS RR TNX \r\n{KB4QQJ|K B 4 Q Q J} TU 2D KS RR TNX 2D ME \r\n";

/***/ })

}]);