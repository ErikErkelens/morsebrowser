"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2403_json"],{

/***/ "./src/wordfiles/IB2403.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2403.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"40","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);