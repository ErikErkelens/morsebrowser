"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2733_txt"],{

/***/ "./src/wordfiles/SB2733.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2733.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ABT AGE AGN ANT BEEN BUG C CALL CLEAR CPI CU CUAGN CUL CW DE DN DR EL ES FB FER FT GA GE GN GND GUD HI HPE HR HW HW? INFO OP OT PSE PWR R RAIN RFI RIG RPRT RPT RR RST SIG SOLID SRI SSB SUN T TU U UP UR W WID WIND WUD  \n";

/***/ })

}]);