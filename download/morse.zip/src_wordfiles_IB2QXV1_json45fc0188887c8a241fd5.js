"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV1_json"],{

/***/ "./src/wordfiles/IB2QXV1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2QXV1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"q","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);