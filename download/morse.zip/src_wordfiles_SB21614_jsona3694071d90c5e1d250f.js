"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB21614_json"],{

/***/ "./src/wordfiles/SB21614.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB21614.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb16.<ar><sk><bt>73?qxv59,kmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);