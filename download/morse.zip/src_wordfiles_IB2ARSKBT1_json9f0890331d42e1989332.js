"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT1_json"],{

/***/ "./src/wordfiles/IB2ARSKBT1.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT1.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR>","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);