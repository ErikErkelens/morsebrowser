"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK1_json"],{

/***/ "./src/wordfiles/IB228BK1.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB228BK1.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"2","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);