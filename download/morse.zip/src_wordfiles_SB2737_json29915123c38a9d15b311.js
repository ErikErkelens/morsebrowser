"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2737_json"],{

/***/ "./src/wordfiles/SB2737.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2737.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);