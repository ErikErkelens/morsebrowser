"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2402_json"],{

/***/ "./src/wordfiles/SB2402.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2402.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);