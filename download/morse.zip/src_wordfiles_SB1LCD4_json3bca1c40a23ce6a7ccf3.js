"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1LCD4_json"],{

/***/ "./src/wordfiles/SB1LCD4.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1LCD4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lcdpgstinrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);