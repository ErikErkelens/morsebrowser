"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1LCD7_json"],{

/***/ "./src/wordfiles/IB1LCD7.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1LCD7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lcdpgstin","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);