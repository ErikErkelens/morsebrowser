"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2598_json"],{

/***/ "./src/wordfiles/SB2598.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2598.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);