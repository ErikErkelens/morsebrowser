"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2164_json"],{

/***/ "./src/wordfiles/IB2164.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2164.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":".","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);