"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C4_txt"],{

/***/ "./src/wordfiles/IB2C4.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C4.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW DE WB2UZE FB CPY RICH ES TNX FER NICE RPRT\t\nRIG IC7300 ES PWR 100W \t\nANT DIPOLE UP 35 FT\t\nWX RAIN ES TEMP 40F\nOK HW? <AR> W2LCW DE WB2UZE K\n";

/***/ })

}]);