"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR36_txt"],{

/***/ "./src/wordfiles/ICR36.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR36.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "TBUE \nUI6U \nV55T \nSVT4 \n44HS \nI46B \nH4S5 \nDJWJ \nID15 \n4J1U \nBUWI \nUJDT \nEE61 \nDUIH \nEBEB \n6WTJ \n1V1T \n64T6 \nT4EJ \nT6VV \nWSIW \nWSU4 \nHTWI \nUWHD \nTH6D \nB4WS \nHTI6 \nB5EV \nBEDB \n4DU6 \n44D5 \nIH6D \nI1JT \nDSVI \nJETU \nBE64 \nD64U \n1VSH \nDV4B \nUWHH \n14U1 \n5JDU \n5EI1 \nE4JE \nT5WI \nBEH1 \nU4W4 \n45HV \nSJW1 \n5JBI \nTUI6 \n54I4 \nWJUI \nST4J \nI6E1 \n44BU \nDDVS \nTJVT \nEDVH \nDWBT \nHDS5 \n6WS6 \nEHV5 \nJD4H \nVIBU \nB45E \nDE1T \nHU1W \n6EIV \nVETH \nIT4I \nVWHW \nTW5V \nSEJB \nT51E \nU4BD \nHSEW \nW41V \nIJ6E \nIVHT \nHIBH \nHB1J \n5SVT \nEJVS \nWJ6B \nE65J \n516U \nE15U \nVW1S \nI1IJ \nVDJ1 \nJBBV \nBE1H \nEU4B \n5EUV \nU5V4 \nVT5W \n66HV \nW1JJ \nUHU4 \nDUW6 \nBVUD \nJBI4 \nT56T \nE4TD \n4H51 \nDD6V \nE4WD \nDUVT \nBD4H \n5W6H \n4EHW \nUSEE \nED6V \nBEVH \nVIT4 \nEUES \nWDV4 \nIEHD \nSW5S \nWUVS \nUHBV \nS65E \nH6JU \nDD4E \nEW1B \nBUHD \nBID4 \nEE45 \nHUH5 \nHTEH \nVU1U \nH5T5 \n6EUH \n5SW5 \nI6SV \nWTDE \n1S4J \n1ITV \nS44S \n6IH6 \nHSEB \n4EBH \nV66W \nH1S4 \nHWBW \nTIHW \nJIBS \nVJ1J \nTDUJ \nJDT6 \nDHS4 \n6JSB \nWETT \n6J4E \nTTVD \n6EHE \nT1HT \n64T1 \nVITU \n4JEJ \n5ITJ \nVT56 \nVJDV \n5H56 \n6SEB \n4EDI \nHST4 \nV4DU \nWBV4 \n5UTS \n14D5 \nSIJS \n5WI1 \n66WE \nV4W1 \nI1BB \n65DE \nUT4B \n4DBB \nEJVJ \n6U6S \nISWJ \nSHBD \nDWTE \nUEJI \nVWTD \nTB1I \nI4DS \nSI1V \nTWWV \nTIH5 \nJWBV \nI4WJ \n6H4I \nVIBE \nIHTW \nTIVH \n1EDH \n4UIV \n";

/***/ })

}]);