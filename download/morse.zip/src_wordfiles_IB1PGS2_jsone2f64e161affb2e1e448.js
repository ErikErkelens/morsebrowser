"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS2_json"],{

/***/ "./src/wordfiles/IB1PGS2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"s","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);