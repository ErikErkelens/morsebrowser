"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2731_json"],{

/***/ "./src/wordfiles/IB2731.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2731.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"7","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);