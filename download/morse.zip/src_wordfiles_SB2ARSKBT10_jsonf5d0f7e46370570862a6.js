"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT10_json"],{

/***/ "./src/wordfiles/SB2ARSKBT10.json":
/*!****************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT10.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb<ar><sk><bt>73?qxv59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);