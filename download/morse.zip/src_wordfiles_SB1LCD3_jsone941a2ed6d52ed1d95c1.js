"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1LCD3_json"],{

/***/ "./src/wordfiles/SB1LCD3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1LCD3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lcdpgstin","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);