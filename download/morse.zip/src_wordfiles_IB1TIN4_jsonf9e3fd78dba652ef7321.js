"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN4_json"],{

/***/ "./src/wordfiles/IB1TIN4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"n","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);