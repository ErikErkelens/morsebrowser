"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1REA2_json"],{

/***/ "./src/wordfiles/IB1REA2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1REA2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"e","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);