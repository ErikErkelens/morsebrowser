"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_TIN_txt"],{

/***/ "./src/wordfiles/BC1_FAM_TIN.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_TIN.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "T \r\nI \r\nN \r\nI \r\nN \r\nT \r\nN \r\nT \r\nI \r\nT \r\nI \r\nN \r\n";

/***/ })

}]);