"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1UWB4_json"],{

/***/ "./src/wordfiles/SB1UWB4.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1UWB4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uwbhoflcdpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);