"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB24011_json"],{

/***/ "./src/wordfiles/SB24011.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB24011.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/16.<ar><sk><bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);