"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV2_json"],{

/***/ "./src/wordfiles/IB2QXV2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2QXV2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"x","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);