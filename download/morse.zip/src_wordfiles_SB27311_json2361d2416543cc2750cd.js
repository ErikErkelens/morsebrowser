"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB27311_json"],{

/***/ "./src/wordfiles/SB27311.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB27311.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,kmy40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);