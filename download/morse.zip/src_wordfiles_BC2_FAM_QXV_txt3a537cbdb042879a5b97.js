"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_QXV_txt"],{

/***/ "./src/wordfiles/BC2_FAM_QXV.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC2_FAM_QXV.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "Q \r\nX \r\nV \r\nX \r\nV \r\nQ \r\nV \r\nQ \r\nX \r\nQ \r\nX \r\nV \r\n";

/***/ })

}]);