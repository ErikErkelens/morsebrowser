"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2734_txt"],{

/***/ "./src/wordfiles/SB2734.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2734.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ES HP CUAGN\nHW?\nAC3D DE N3GE\nAGE 37\nANT DIPOLE UP 73 FT\nANT EFHW UP 37 FT\nANT WIRE IN ATTIC\nAGE 73 RETIRED DOCTOR\nPSE RPT RIG ES ANT?\nOP FLIP\nRIG TEN TEC\nSOLID SIG HR\nCOLD ES RAIN 3 C\nCUL DR SOCHO\n";

/***/ })

}]);