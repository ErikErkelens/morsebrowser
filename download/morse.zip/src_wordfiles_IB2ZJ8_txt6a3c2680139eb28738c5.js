"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ8_txt"],{

/***/ "./src/wordfiles/IB2ZJ8.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2ZJ8.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL \nAR \nAZ \nCA \nCO \nCT \n{DE|delaware} \nFL \n{GA|georgia} \n{HI|hawaii} \n{ID|idaho} \nIL \n{IN|indiana} \nIA \n{LA|louisiana} \nNE \nNH \nNC \nND \nNJ \n{OH|ohio} \n{OR|oregon} \nPA \nRI \nSC \nSD \nTN \nUT \nWA \nWI \n";

/***/ })

}]);