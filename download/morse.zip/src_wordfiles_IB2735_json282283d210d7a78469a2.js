"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2735_json"],{

/***/ "./src/wordfiles/IB2735.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2735.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);