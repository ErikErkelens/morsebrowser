"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV3_Fam_Phrases_4L_txt"],{

/***/ "./src/wordfiles/ADV3_Fam_Phrases_4L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/ADV3_Fam_Phrases_4L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "NOW TO \r\nNOW TO KILL TWO \r\nNOW TO KILL TWO BIRDS WITH \r\nNOW TO KILL TWO BIRDS WITH ONE STONE \r\n{<BT>|}\r\nLET THE \r\nLET THE CAT OUT \r\nLET THE CAT OUT OF THE \r\nLET THE CAT OUT OF THE PAPER BAG \r\n{<BT>|}\r\nWHO PUT \r\nWHO PUT THE ELEPHANT \r\nWHO PUT THE ELEPHANT IN THE \r\nWHO PUT THE ELEPHANT IN THE DINNING ROOM \r\n{<BT>|}\r\nITS TOO \r\nITS TOO LATE TO \r\nITS TOO LATE TO EAT OUT \r\nITS TOO LATE TO EAT OUT AGAIN TONIGHT \r\n{<BT>|}\r\nNOW GET \r\nNOW GET A TASTE \r\nNOW GET A TASTE OF YOUR \r\nNOW GET A TASTE OF YOUR OWN MEDICINE \r\n{<BT>|}\r\nITS BEEN \r\nITS BEEN A HEAT \r\nITS BEEN A HEAT WAVE THIS \r\nITS BEEN A HEAT WAVE THIS LAST YEAR ";

/***/ })

}]);