"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1UWB3_json"],{

/***/ "./src/wordfiles/SB1UWB3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1UWB3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uwbhoflcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);