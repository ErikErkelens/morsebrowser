"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1REA4_json"],{

/***/ "./src/wordfiles/IB1REA4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1REA4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"a","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);