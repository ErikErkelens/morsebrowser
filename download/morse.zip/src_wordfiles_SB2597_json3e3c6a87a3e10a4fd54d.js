"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2597_json"],{

/***/ "./src/wordfiles/SB2597.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2597.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);