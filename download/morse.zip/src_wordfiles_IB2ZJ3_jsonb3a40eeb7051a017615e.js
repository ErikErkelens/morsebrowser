"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ3_json"],{

/***/ "./src/wordfiles/IB2ZJ3.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2ZJ3.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"zj","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);