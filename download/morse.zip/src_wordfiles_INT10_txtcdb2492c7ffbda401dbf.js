"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT10_txt"],{

/***/ "./src/wordfiles/INT10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/INT10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<AR> \n<BT> \n<SK> \n599 \n73 \n5NN \nABT \nAGE \nAGN \nAM \nANT \nB4 \nBEEN \nBK \nBUG \nC \nCALL \nCFM \nCLEAR \nCPI \nCPY \nCQ \nCU \nCUAGN \nCUL \nCW \nDE \nDN \nDR \nDX \nEL \nES \nFB \nFER \nFM \nFT \nGA \nGE \nGM \nGN \nGND \nGUD \nHAM \nHI \nHPE \nHR \nHW \nHW? \nINFO \nK \nOK \nOM \nOP \nOT \nPSE \nPWR \nQRM \nQRN \nQRP \nQRQ \nQRS \nQRT \nQRZ \nQSB \nQSL \nQSO \nQSY \nQTH \nR \nRAIN \nRFI \nRIG \nRPRT \nRPT \nRR \nRST \nRX \nSIG \nSKED \nSOLID \nSRI \nSSB \nSUN \nT \nTEMP \nTKS \nTNX \nTU \nTX \nU \nUP \nUR \nVERT \nVY \nW \nWID \nWIND \nWPM \nWUD \nWX \nYAGI \nYRS \n";

/***/ })

}]);