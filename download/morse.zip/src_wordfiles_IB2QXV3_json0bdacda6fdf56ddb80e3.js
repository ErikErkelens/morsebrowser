"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV3_json"],{

/***/ "./src/wordfiles/IB2QXV3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2QXV3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"qx","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);