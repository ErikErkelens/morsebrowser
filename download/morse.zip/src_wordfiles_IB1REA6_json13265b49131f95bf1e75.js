"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1REA6_json"],{

/***/ "./src/wordfiles/IB1REA6.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1REA6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uwbhof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);